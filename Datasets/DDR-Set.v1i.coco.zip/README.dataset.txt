# DDR-Set > 2023-03-29 3:42pm
https://universe.roboflow.com/ahmed-alsaba-0xutg/ddr-set

Provided by a Roboflow user
License: CC BY 4.0

